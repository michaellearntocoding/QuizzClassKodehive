﻿using System;
namespace Quiz2
{
	interface iManager
	{
		void ListManager();
	}
}

