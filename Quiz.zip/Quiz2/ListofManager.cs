﻿using System;
namespace Quiz2
{
	public class ListofManager
	{
        public void ListManager()
        {
            GeneralManager gm = new GeneralManager();
            Guid id = Guid.NewGuid();
            DateTime bod = new DateTime(1995, 4, 28);

            List<GetInfo> ListManager = new List<GetInfo>();
            ListManager.Add(new GetInfo() { ID = id, Name = "Sam", Position = "Manager", BoD = bod, Salary = 12_000_000, ManagerType = "IT" });
            ListManager.Add(new GetInfo() { ID = id, Name = "John", Position = "Manager", BoD = bod, Salary = 12_000_000, ManagerType = "Sales" });
            ListManager.Add(new GetInfo() { ID = id, Name = "Rudy", Position = "CEO", BoD = bod, Salary = 15_000_000, ManagerType = "General" });

            foreach(var x in ListManager)
            {
                Console.WriteLine($"ID : {x.ID}");
                Console.WriteLine($"Name : {x.Name}");
            }
        }
    }

}

