﻿using System;
namespace Quiz2
{
	public class ListofStaff
	{
		public void ListofSalesStaff()
		{
            
        }
	}
}

