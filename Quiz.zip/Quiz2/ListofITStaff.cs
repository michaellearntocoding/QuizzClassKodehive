﻿//using System;
//namespace Quiz2
//{
//	public class ListofITStaff
//	{
//		public void ListITStaff()
//		{
//            Guid id = Guid.NewGuid();
//            DateTime bod = new DateTime(2000, 5, 10);

//            List<GetInfo> StaffIT = new List<GetInfo>();
//            StaffIT.Add(new GetInfo() { ID = id, Name = "Budi", Position = "Staff", BoD = bod, Salary = 12_000_000, Division = "IT" });

//            foreach( var x in StaffIT)
//            {
//                Console.WriteLine
//            }
//        }
//    }
//}

