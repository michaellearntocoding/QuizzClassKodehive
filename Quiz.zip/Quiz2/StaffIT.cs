﻿using System;
namespace Quiz2
{
	public class StaffIT : ManagerIT
	{
        public override void GetInfo()
        {
            Guid id = Guid.NewGuid();
            DateTime bod = new DateTime(2000, 5, 10);

            List<GetInfo> StaffIT = new List<GetInfo>();
            StaffIT.Add(new GetInfo() { ID = id, Name = "Budi", Position = "Staff", BoD = bod, Salary = 12_000_000, Division = "IT" });


            foreach (var x in StaffIT)
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Division \t: {x.Division}");

            }
            
        }
        public void DataStaffIT()
        {
            Guid id = Guid.NewGuid();
            DateTime bod = new DateTime(2000, 5, 10);

            List<GetInfo> StaffIT = new List<GetInfo>();
            StaffIT.Add(new GetInfo() { ID = id, Name = "Budi", Position = "Staff", BoD = bod, Salary = 12_000_000, Division = "IT" });



            foreach (var x in StaffIT)
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
            }
        }
    }
}

