﻿using System;
namespace Quiz2
{
	public class ManagerIT : CEO
	{
		public override void GetInfo()
		{
            Guid id = Guid.NewGuid();
            DateTime bod = new DateTime(2000, 5, 10);

            List<string> staffList = new List<string>();
            staffList.Add("Budi");

            List<GetInfo> ManagerIT = new List<GetInfo>();
            ManagerIT.Add(new GetInfo() { ID = id, Name = "Sam", Position = "Manager", BoD = bod, Salary = 12_000_000, ManagerType = "IT" });

            foreach (var x in ManagerIT)
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Manager type \t: {x.ManagerType}");

            }

            Console.WriteLine("List of IT Staff : ");

            StaffIT staffIT = new StaffIT();
            staffIT.DataStaffIT();
        }

        
	}
}

