﻿using System;
namespace Quiz2
{
    public class StaffSales2 : ManagerSales
    {
        public override void GetInfo()
        {
            Guid id = Guid.NewGuid();
            DateTime bod = new DateTime(2000, 5, 10);

            List<GetInfo> StaffSales2 = new List<GetInfo>();
            StaffSales2.Add(new GetInfo() { ID = id, Name = "Doni", Position = "Sales", BoD = bod, Salary = 3_000_000, Division = "Sales" });

            foreach (var x in StaffSales2)
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Division \t: {x.Division}");
            }
        }
    }
}

