﻿using System;
namespace Quiz2
{
	public class GeneralManager : CEO
	{
        public override void GetInfo()
        { 
            Guid id = Guid.NewGuid();
            DateTime bod = new DateTime(1995, 4, 28);

            List<GetInfo> GeneralManager = new List<GetInfo>();
            GeneralManager.Add(new GetInfo() { ID = id, Name = "Rudy", Position = "CEO", BoD = bod, Salary = 15_000_000, ManagerType = "General" });

            foreach (var x in GeneralManager)
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Manager type \t: {x.ManagerType}");
            }

        }
    }
}

