﻿using System;
namespace Quiz2
{
	public class ManagerSales : CEO
	{
        public override void GetInfo()
        {
            Guid id = Guid.NewGuid();
            DateTime bod = new DateTime(2000, 5, 10);




            List<string> Staff = new List<string>();
            Staff.Add("Jony");
            Staff.Add("Doni");
            

            List<GetInfo> ManagerSales = new List<GetInfo>();
            ManagerSales.Add(new GetInfo() { ID = id, Name = "John", Position = "Manager", BoD = bod, Salary = 12_000_000, ManagerType = "Sales" });

            foreach (var x in ManagerSales)
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Manager type \t: {x.ManagerType}");
            }
            Console.WriteLine("Nama staff: ");
            foreach (var z in Staff)
            {
                Console.WriteLine(z);
            }
        }
    }
}

