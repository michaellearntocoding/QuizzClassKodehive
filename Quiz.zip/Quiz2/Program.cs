﻿//// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using System;

namespace Quiz2
{
    class Program
    {
        static void Main(String[] args)
        {
            CEO ceo = new CEO();
            ManagerIT managerIT = new ManagerIT();
            ManagerSales managerSales = new ManagerSales();
            GeneralManager generalManager = new GeneralManager();
            StaffIT staffIT = new StaffIT();
            StaffSales1 staffSales1 = new StaffSales1();

            managerIT.GetInfo();

            //ceo.GetInfo();

            //staffIT.GetInfo();

        }
    }
}