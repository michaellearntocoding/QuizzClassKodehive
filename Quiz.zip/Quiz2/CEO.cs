﻿using System;
namespace Quiz2
{
	public class CEO
	{
		public virtual void GetInfo()
		{
            ListofManager managerList = new ListofManager();

            

            Guid id = Guid.NewGuid();
            DateTime bod = new DateTime(1995, 4, 28);

            //List<GetInfo> Managers = new List<GetInfo>();
            //Managers.Add(new GetInfo() { ID = id, Name = "Sam", Position = "Manager", BoD = bod, Salary = 12_000_000, ManagerType = "IT" });
            //Managers.Add(new GetInfo() { ID = id, Name = "John", Position = "Manager", BoD = bod, Salary = 12_000_000, ManagerType = "Sales" });
            //Managers.Add(new GetInfo() { ID = id, Name = "Rudy", Position = "CEO", BoD = bod, Salary = 15_000_000, ManagerType = "General" });





            List<GetInfo> CEO = new List<GetInfo>();
            CEO.Add(new GetInfo() { ID = id, Name = "Rudy", Position = "CEO", BoD = bod, Salary = 15_000_000, CompanyName = "ABC" });

            foreach (var x in CEO)
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Company name \t: {x.CompanyName}");

            }
            Console.WriteLine("Additional Information:");
            managerList.ListManager();

            //var managerName = 
            //Console.WriteLine("List of manager : ");
            //foreach (var x in Managers)
            //{
            //    Console.WriteLine(x.Name);
            //}
        }
		public CEO()
		{
		}
	}
}

