﻿using System;
namespace Quiz2
{
	public class StaffSales1 : ManagerSales
	{
        public override void GetInfo()
        {
            Guid id = Guid.NewGuid();
            DateTime bod = new DateTime(2000, 5, 10);

            List<GetInfo> SalesStaff1 = new List<GetInfo>();
            SalesStaff1.Add(new GetInfo() { ID = id, Name = "Jony", Position = "Sales", BoD = bod, Salary = 3_000_000, Division = "Sales" });
            //StaffIT.Add(new GetInfo() { ID = id, Name = "SalesNo2", Position = "sales", BoD = bod, Salary = 3_500_000 });

            foreach (var x in SalesStaff1)
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Division \t: {x.Division}");
            }
            



        }
    }
}

