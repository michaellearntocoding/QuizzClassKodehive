﻿//using System;
//namespace KodehiveSesion3
//{
//	public class ListPage
//	{
//		public List<string> Pages { get; set; }
		
//	}
//}

