﻿//using System;
//namespace KodehiveSesion3
//{
//	public class ExceptionPages
//	{
//		public ExceptionPages()
//		{
//		}
//		public static void GetInput()
//		{
//			try
//			{
//                Console.Write("Select page : ");
//                int pageValue = Convert.ToInt32(Console.ReadLine()) - 1;
//            }
//			catch (System.Exception e)
//			{
//			}
//		}
//	}
//}

