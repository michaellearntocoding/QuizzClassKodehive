﻿using System;
namespace KodehiveSesion3
{
    public class dict
    {
        private Dictionary<string, List<string>> page;
        public Dictionary {get; set;}
    }
    

}

