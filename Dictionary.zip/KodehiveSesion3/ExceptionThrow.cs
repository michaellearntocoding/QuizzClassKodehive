﻿using System;
namespace KodehiveSesion3
{
	public class ExceptionThrow
	{
		public ExceptionThrow()
		{
		}

		public void setNum (int x, int y)
		{
			try
			{
				int result = divider(x, y);
				Console.WriteLine($"Result is {result}");
			}
			catch (System.Exception e)
			{
                Console.WriteLine($"{e.Message}");			// Hanya tampilin pesannya aja
                Console.WriteLine($"Error type is {e}");	// 
			}
			finally
			{
				Console.WriteLine("Error");
			}
		}
		private int divider(int x, int y)
		{
			return (x / y);
		}
	}
}

