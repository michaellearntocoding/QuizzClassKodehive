﻿//// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using System;
using static System.Net.Mime.MediaTypeNames;


namespace KodehiveSesion3
{
    class Program
    {
        static void Main(String[] args)
        {
            ////////////////////////// Number Positional Argument //////////////////////////
            //string product = "Coke";
            //int price = 10000;
            //Console.WriteLine("{0} is {1:C}. ", product, price); // :C untuk currency and more

            //// EXEPTION  & ERROR HANDLING//
            //ErrorHandlingDividedByZero x = new ErrorHandlingDividedByZero();
            //x.Division(10, 0);


            //ExceptionThrow test = new ExceptionThrow();
            //Console.WriteLine(test.setNum(10, 1));



            ////////////////////////// DICTIONARY //////////////////////////
            //Dictionary<string, string> dic = new Dictionary<string, string>();
            //dic.Add("peserta1", "ahmad");
            //dic.Add("peserta2", "Moh");

            //dic["peserta1"] = "John";

            //Console.WriteLine(dic["peserta1"]);

            //foreach (string key in dic.Keys)
            //{
            //    Console.WriteLine($"{key} : {dic[key]}");
            //}

            ////Dictionary<int, DataPesesrtaModel> dictio = new Dictionary<int, DataPesesrtaModel>();

            ////Dictionary<int, Dictionary<string, string>> dictonary = new Dictionary<int, Dictionary<string, string>>();


            //// Menggunakan Linq
            //var dicFilter = dic.Where(x => x.Value == "Ahmad");
            //Console.WriteLine(dicFilter);


            // EXERCISES DICTIONARY //
            // NESTED DICTIONARY

            
            // TRY 1

            //Dictionary<string, List<string>> page = new Dictionary<string, List<string>>();
            //List<string> NamaPage = new List<string>() { "Home", "Profile", "Setting" };
            ////string home = NamaPage[0];
            ////string profile = NamaPage[1];
            ////string setting = NamaPage[2];


            //page.Add("page", NamaPage);



            //Dictionary<string, string> Home = new Dictionary<string, string>();
            //Dictionary<string, string> Profile = new Dictionary<string, string>();
            //Dictionary<string, string> Setting = new Dictionary<string, string>();

            //Home.Add("Contact", "Kontak");
            //Home.Add("Setting", "Pengaturan");
            //Home.Add("About us", "Tentang kami");

            //Profile.Add("Edit", "Ubah");
            //Profile.Add("Name", "Nama");
            //Profile.Add("Address", "Alamat");

            //Setting.Add("Password", "Kata sandi");
            //Setting.Add("Save", "Simpan");
            //Setting.Add("Log out", "Keluar");



            //int i = 1;


            //foreach (string key in page.Keys)
            //{

            //    foreach (string n in NamaPage)
            //    {
            //        Console.Write(i + " ");
            //        i++;
            //        Console.WriteLine(n);
            //    }
            //}

            //Console.Write("Select page : ");
            //int pageValue = Convert.ToInt32(Console.ReadLine()) - 1;



            //if (NamaPage[pageValue] == "Home")
            //{
            //    foreach (string key in Home.Keys)
            //    {
            //        Console.WriteLine($"\n{key} \t{Home[key]}");
            //    }
            //}
            //else if (NamaPage[pageValue] == "Profile")
            //{
            //    foreach (string key in Profile.Keys)
            //    {
            //        Console.WriteLine($"\n{key} \t{Profile[key]}");
            //    }
            //}
            //else if (NamaPage[pageValue] == "Setting")
            //{
            //    foreach (string key in Setting.Keys)
            //    {
            //        Console.WriteLine($"\n{key} \t{Setting[key]}");
            //    }
            //}
            //else
            //{
            //    Console.WriteLine("Input tidak valid..");
            //}


            // TRY 2 WITH EXCEPTION HANDLER
            Dictionary<string, List<string>> page = new Dictionary<string, List<string>>();
            List<string> NamaPage = new List<string>() { "Home", "Profile", "Setting" };

            page.Add("page", NamaPage);

            Dictionary<string, string> Home = new Dictionary<string, string>();
            Dictionary<string, string> Profile = new Dictionary<string, string>();
            Dictionary<string, string> Setting = new Dictionary<string, string>();

            Home.Add("Contact", "Kontak");
            Home.Add("Setting", "Pengaturan");
            Home.Add("About us", "Tentang kami");

            Profile.Add("Edit", "\tUbah");
            Profile.Add("Name", "\tNama");
            Profile.Add("Address", "Alamat");

            Setting.Add("Password", "Kata sandi");
            Setting.Add("Save\t", "Simpan");
            Setting.Add("Log out", "Keluar");

            int i = 1;

            foreach (string key in page.Keys)
            {
                foreach (string n in NamaPage)
                {
                    Console.Write(i + ". ");
                    i++;
                    Console.WriteLine(n);
                }
            }

            try
            {
                Console.Write("Select page : ");
                int pageValue = Convert.ToInt32(Console.ReadLine()) - 1;
                if (NamaPage[pageValue] == "Home")
                {
                    foreach (string key in Home.Keys)
                    {
                        Console.WriteLine($"\n{key} \t{Home[key]}");
                    }
                }
                else if (NamaPage[pageValue] == "Profile")
                {
                    foreach (string key in Profile.Keys)
                    {
                        Console.WriteLine($"\n{key} \t{Profile[key]}");
                    }
                }
                else if (NamaPage[pageValue] == "Setting")
                {
                    foreach (string key in Setting.Keys)
                    {
                        Console.WriteLine($"\n{key} \t{Setting[key]}");
                    }
                }
                else
                {
                    Console.WriteLine("Input tidak valid..");
                }
            }
            catch (System.Exception e)
            {
                Console.WriteLine($"Error pilih yang ada di atas. {e.Message}");			// Hanya tampilin pesannya aja
                Console.WriteLine($"Error type is {e}");    // 
            }

        }
        public void DictionaryPage()
        {

        }
    }
}
