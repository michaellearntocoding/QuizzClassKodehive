﻿using System;
namespace KodehiveSesion3
{
	public class Temperature
	{
		

		//int temperature = 0;

		//public void ShowTemp()
		//{

		//}

	}
}

