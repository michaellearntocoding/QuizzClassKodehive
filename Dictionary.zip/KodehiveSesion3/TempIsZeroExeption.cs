﻿using System;
namespace KodehiveSesion3
{
	public class TempIsZeroExeption 
	{
		public TempIsZeroExeption()
		{
		}
	}
}

