using System;
using Hewan;

namespace HewanAir
{
    class HewanAirClass : HewanClass
    {
        public void Berenang()
        {
            Console.WriteLine("Hewan di air semua berenang.");
        }
        public override void Bernafas()
        {
            Console.WriteLine("Hewan air juga bernafas menggunakan insang.");
        }
    }
}