using System;
using Hewan;

namespace HewanUdara
{

    class HewanUdaraClass : HewanClass
    {
        public void Terbang()
        {
            Console.WriteLine("Hewan udara semua bisa terbang.");
        }
    }
}