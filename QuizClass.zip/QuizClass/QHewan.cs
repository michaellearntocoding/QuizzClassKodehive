using System;

namespace Hewan
{
    class HewanClass
    {
        public virtual void Bernafas()
        {
            Console.WriteLine("Hewan bernafas.");
        }
    }

}