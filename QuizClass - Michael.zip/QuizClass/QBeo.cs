using System;
using Hewan;
using HewanUdara;

namespace Beo
{
    class BeoClass : HewanUdaraClass
    {

    }

}