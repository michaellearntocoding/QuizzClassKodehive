using System;
using Hewan;
using HewanAir;

namespace Paus
{
    class PausClass : HewanAirClass
    {

    }

}