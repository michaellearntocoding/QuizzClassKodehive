using System;
using Hewan;
using HewanUdara;

namespace Elang
{
    class ElangClass : HewanUdaraClass
    {

    }

}