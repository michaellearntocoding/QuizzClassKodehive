using System;
using Hewan;
using HewanAir;

namespace Hiu
{
    class HiuClass : HewanAirClass
    {

    }

}