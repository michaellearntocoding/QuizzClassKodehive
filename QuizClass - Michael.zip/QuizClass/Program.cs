﻿using System;
using Hewan;
using HewanAir;
using HewanDarat;
using HewanUdara;
using Hiu;
using Elang;
using Kambing;
using Kucing;
using Paus;
using Beo;

namespace HewanMain
{
    class AnimalKingdom
    {
        static void Main(String[] args)
        {
            HewanClass hewan1 = new HewanClass();
            hewan1.Bernafas();
            

            HewanDaratClass hewanDarat = new HewanDaratClass();
            hewanDarat.Jalan();
            hewanDarat.Bernafas();

            HewanUdaraClass hewanUdara = new HewanUdaraClass();
            hewanUdara.Terbang();
            hewanUdara.Bernafas();


            KambingClass kambingMuda = new KambingClass();
            kambingMuda.Bernafas();

            KucingClass kucingHoki = new KucingClass();
            kucingHoki.Jalan();

            PausClass pausDiLaut = new PausClass();
            pausDiLaut.Bernafas();

            HiuClass hiu1 = new HiuClass();
            hiu1.Bernafas();
            hiu1.Berenang();

            BeoClass bebeo = new BeoClass();
            bebeo.Terbang();

            ElangClass eelang = new ElangClass();
            eelang.Bernafas();

        }
    }
}