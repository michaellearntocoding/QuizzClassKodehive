using System;
using Hewan;
using HewanDarat;

namespace Kucing
{
    class KucingClass : HewanDaratClass
    {

    }
}