using System;
using Hewan;

namespace HewanDarat
{
    class HewanDaratClass : HewanClass
    {
        public void Jalan()
        {
            Console.WriteLine("Hewan darat berjalan.");
        }
        public override void Bernafas()
        {
            Console.WriteLine("Hewan darat juga bernafas.");
        }
    }
}