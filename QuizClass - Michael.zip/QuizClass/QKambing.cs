using System;
using Hewan;
using HewanDarat;

namespace Kambing
{
    class KambingClass : HewanDaratClass
    {

    }
}