﻿using System;

namespace Quiz2New
{
    class Program
    {
        static void Main(String[] args)
        {
            CEO ceo = new CEO();
            ManagerIT managerIT = new ManagerIT();
            ManagerSales managerSales = new ManagerSales();
            ManagerGeneralAffair managerGeneralAffair = new ManagerGeneralAffair();
            StaffIT staffIT = new StaffIT();
            StaffSales1 staffSales1 = new StaffSales1();
            StaffSales2 staffSales2 = new StaffSales2();

            //ceo.GetInfo();
            managerIT.GetInfo();
            //ManagerSales.GetInfo();
            //ManagerGeneralAffair.GetInfo();
            //staffIT.GetInfo();
            //staffSales1.GetInfo();
            //staffSales2.GetInfo();





        }
    }
}

