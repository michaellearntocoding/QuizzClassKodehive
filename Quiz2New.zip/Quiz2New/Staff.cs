﻿using System;
namespace Quiz2New
{
	public class Staff
	{
        public List<ListStaff> GetStaffIT()
        {
            Guid StaffITID = Guid.NewGuid();
            DateTime bodStaffIT = new DateTime(1999, 12, 25);

            List<ListStaff> staffIT = new List<ListStaff>();
            staffIT.Add(new ListStaff()
            {
                ID = StaffITID,
                Name = "Dono",
                Position = "Staff",
                BoD = bodStaffIT,
                Salary = 7_000_000,
                Division = "IT"
            });
            return staffIT;
        }

        public List<ListStaff> GetStaffSales1()
        {
            Guid StaffSales1ID = Guid.NewGuid();
            DateTime bodStaffSales1 = new DateTime(1995, 10, 25);

            List<ListStaff> staffIT = new List<ListStaff>();
            staffIT.Add(new ListStaff()
            {
                ID = StaffSales1ID,
                Name = "Kasino",
                Position = "Staff",
                BoD = bodStaffSales1,
                Salary = 5_000_000,
                Division = "Sales"
            });
            return staffIT;
        }

        public List<ListStaff> GetStaffSales2()
        {
            Guid StaffSales2ID = Guid.NewGuid();
            DateTime bodStaffSales2 = new DateTime(1989, 02, 20);

            List<ListStaff> staffIT = new List<ListStaff>();
            staffIT.Add(new ListStaff()
            {
                ID = StaffSales2ID,
                Name = "Indrp",
                Position = "Staff",
                BoD = bodStaffSales2,
                Salary = 6_000_000,
                Division = "Sales"
            });
            return staffIT;
        }
    }
}

