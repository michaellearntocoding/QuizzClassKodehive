﻿using System;
namespace Quiz2New
{
	public class ManagerGeneralAffair : CEO
	{
        public override void GetInfo()
        {
            Manager manager = new Manager();

            foreach (var x in manager.GetManagerGA())
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Manager type \t: {x.ManagerType}");
            }
        }
    }
}

