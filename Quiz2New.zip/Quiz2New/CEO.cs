﻿using System;
namespace Quiz2New
{
	public class CEO : Manager
	{
		public virtual void GetInfo()
		{
			Guid id = Guid.NewGuid();
			DateTime bod = new DateTime(1999, 12, 25);

            List<ListCEO> ceo = new List<ListCEO>();
			ceo.Add(new ListCEO()
			{
				ID = id,
				Name = "Rudy",
				Position = "CEO",
				BoD = bod,
				Salary = 35_000_000,
				CompanyName = "MoneyForLyfe"
			});

			foreach (var x in ceo)
			{
				Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Company name \t: {x.CompanyName}");
            }

			Console.WriteLine("List of managers :");

            Manager manager = new Manager();

            foreach (var x in manager.GetManagerIT())
            {
                Console.WriteLine($"ID : {x.ID}");
                Console.WriteLine($"Name : {x.Name}");
            }
            foreach (var x in manager.GetManagerSales())
            {
                Console.WriteLine($"ID : {x.ID}");
                Console.WriteLine($"Name : {x.Name}");
            }
            foreach (var x in manager.GetManagerGA())
            {
                Console.WriteLine($"ID : {x.ID}");
                Console.WriteLine($"Name : {x.Name}");
            }
            ////////////////////////////////////////////////////////////////////

            //ManagerIT managerit = new ManagerIT();
            //         foreach (var z in managerit.managerIT)
            //         {
            //             Console.WriteLine($"{z.Name}");
            //             Console.WriteLine(z.ID);
            //         }

            //Manager manager = new Manager();
            //foreach (var g in manager)
            //{

            //}
        }
    }
}

