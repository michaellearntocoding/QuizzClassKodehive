﻿using System;
namespace Quiz2New
{
	public class Manager 
	{
        public List<ListManager> GetManagerIT()
        {
            Guid ITManagerID = Guid.NewGuid();
            DateTime bodITManager = new DateTime(1999, 12, 25);

            List<ListManager> managerIT = new List<ListManager>();
            managerIT.Add(new ListManager()
            { 
                ID = ITManagerID,
                Name = "Budi",
                Position = "Manager",
                BoD = bodITManager,
                Salary = 15_000_000,
                ManagerType = "IT Manager"
            });
            return managerIT;
        }

        public List<ListManager> GetManagerSales()
        {
            Guid SalesManagerID = Guid.NewGuid();
            DateTime bodSalesManager = new DateTime(1992, 04, 10);

            List<ListManager> managerSales = new List<ListManager>();
            managerSales.Add(new ListManager()
            {
                ID = SalesManagerID,
                Name = "John",
                Position = "Manager",
                BoD = bodSalesManager,
                Salary = 15_000_000,
                ManagerType = "Sales Manager"
            });
            return managerSales;
        }

        public List<ListManager> GetManagerGA()
        {
            Guid GAManagerID = Guid.NewGuid();
            DateTime bodGAManager = new DateTime(1991, 11, 12);


            List<ListManager> managerGA = new List<ListManager>();
            managerGA.Add(new ListManager()
            {
                ID = GAManagerID,
                Name = "Charles",
                Position = "Manager",
                BoD = bodGAManager,
                Salary = 10_000_000,
                ManagerType = "GA Manager"
            });

            return managerGA;
        }

        
            
        

    }
}

