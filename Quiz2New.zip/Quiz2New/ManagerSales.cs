﻿using System;
namespace Quiz2New
{
	public class ManagerSales : CEO
	{
        public override void GetInfo()
        {
            Manager manager = new Manager();

            foreach (var x in manager.GetManagerSales())
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Manager type \t: {x.ManagerType}");
            }
            Console.WriteLine("List of staff member : ");
            Staff staff = new Staff();
            foreach (var x in staff.GetStaffSales1())
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
            }
            foreach (var x in staff.GetStaffSales2())
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
            }
        }
    }
}

