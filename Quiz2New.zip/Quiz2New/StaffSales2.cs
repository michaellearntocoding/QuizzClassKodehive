﻿using System;
namespace Quiz2New
{
	public class StaffSales2 : ManagerSales
	{
        public override void GetInfo()
        {
            Staff staff = new Staff();

            foreach (var x in staff.GetStaffSales2())
            {
                Console.WriteLine($"ID \t\t: {x.ID}");
                Console.WriteLine($"Name \t\t: {x.Name}");
                Console.WriteLine($"Position \t: {x.Position}");
                Console.WriteLine($"Date of Birth \t: {x.BoD}");
                Console.WriteLine($"Salary \t\t: {x.Salary}");
                Console.WriteLine($"Division \t: {x.Division}");
            }
        }
    }
}

