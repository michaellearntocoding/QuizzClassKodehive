﻿using System;
namespace Quiz2New
{
	public class ListStaff
	{
        public Guid ID { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public DateTime BoD { get; set; }
        public double Salary { get; set; }
        public string Division { get; set; }
    }
}

